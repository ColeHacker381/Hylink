# Database Schema v0.1 (logical)

All primary keys TEXT UUID or ULID; all dates ISO UTC strings unless stated. SQLite FK enforced; indexed foreign keys and due dates; reversible or versioned migrations.

## Core
- `schema_migrations(id, applied_at)`
- `settings(key PK, value_json, updated_at)`
- `domain_events(event_id PK, type, version, aggregate_id, payload_json, occurred_at, created_at)`
- `event_consumptions(event_id, consumer, processed_at, PRIMARY KEY(event_id,consumer))`

## Quests and calendar
- `quests(id PK, title, description, kind, status, difficulty, priority, due_at, due_timezone, created_at, completed_at, parent_quest_id FK nullable, recurrence_rule nullable, rule_snapshot_json nullable)`
- `quest_steps(id PK, quest_id FK, title, position, status)`
- `quest_place_links(quest_id FK, place_id FK, PRIMARY KEY(quest_id,place_id))`
- `events(id PK, title, starts_at, ends_at, timezone, recurrence_rule, place_id FK nullable, reminder_json)`
- `quest_completions(id PK, quest_id FK, occurrence_key nullable, completed_at, UNIQUE(quest_id, occurrence_key))` (non-recurring uses stable sentinel occurrence key)

## World
- `regions(id PK, name, slug, boundary_geojson, nearby_radius_miles, atlas_x, atlas_y, artwork_id, status, created_at)`
- `places(id PK, name, lat, lng, private_address, primary_region_id nullable, classification_override nullable, icon_id, created_at)`
- `place_appearances(place_id PK FK, art_asset_id, label_dx, label_dy, icon_scale)`
- `region_art_assets(id PK, region_id FK, uri, attribution, anchor_metadata_json)`
- `visits(id PK, place_id FK, arrived_at, departed_at nullable, source, user_confirmed)` (opt-in)

## Game
- `game_rulesets(id PK, version, effective_at, xp_curve_json, difficulty_rewards_json, skill_rules_json, enabled)`
- `xp_ledger(id PK, source_key UNIQUE, character_id, skill_id nullable, amount, ruleset_id, awarded_at)`
- `rupee_ledger(id PK, source_key UNIQUE, delta, reason, created_at)`
- `skills(id PK, code UNIQUE, name, active)`
- `achievements(id PK, code UNIQUE, rule_json, reward_json, active)`
- `achievement_unlocks(id PK, achievement_id FK, source_key UNIQUE, unlocked_at)`
- `reward_catalog(id PK, title, price_rupees, optional_real_budget_category_id, enabled)`
- `reward_redemptions(id PK, reward_id FK, cost_rupees, redeemed_at, status)`
- `hero_profile(id PK, title, appearance_json)`

## Treasury
- `financial_accounts(id PK, name, type, currency, active)`
- `transactions(id PK, account_id FK, amount_cents SIGNED INTEGER, currency, category_id nullable, occurred_at, description, transfer_group_id nullable, source)`
- `budget_categories(id PK, name, monthly_limit_cents, active)`
- `financial_goals(id PK, name, target_cents, target_date nullable, basis, linked_account_id nullable)`
- `goal_snapshots(id PK, goal_id FK, value_cents, measured_at)` (derived or imported)

## Chronicle/notifications
- `memories(id PK, place_id nullable, quest_id nullable, recorded_at, text, attachment_uri nullable)`
- `notification_preferences(id PK, kind, enabled, cooldown_minutes, quiet_hours_json)`
- `notification_delivery_log(id PK, scope_key, event_id nullable, attempted_at, result)`

## Notes
- A signed transaction amount is an inflow/outflow in cents; transfers are paired and excluded from income/expense reports.
- Virtual currency NEVER shares tables with financial transactions.
- Financial balances are computed from accounts' opening values + transactions, not optimistic gameplay guesses.
- Financial goal progress can be manual or backed by account balances; a goal achievement is only awarded from verified snapshot logic.
- Prevent double XP by ledger unique source key e.g. `quest-completion:<id>:character:<id>`.
- Keep full addresses private and exclude from analytics/AI by default.
