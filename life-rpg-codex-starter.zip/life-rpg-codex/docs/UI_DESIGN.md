# UI Design v0.1

## Style
Hybrid adventure journal: parchment/sepia backgrounds and illustrations, deep pine green actionable surfaces, bronze/gold highlights, brown engraved borders. Modern readable input controls and charts. Original visual identity, no proprietary Zelda assets or icon fonts.

## Tokens (initial suggestions)
- parchment #EFE0B5; parchmentLight #F7EED6; ink #32281C; pine #314D3A; bronze #AD8245; accent #8EA575; danger #A95549.
- 8px spacing grid; touch targets >=44x44pt; support dynamic type, high contrast, reduced motion.
- Reusable components: `ParchmentScreen`, `QuestCard`, `RegionBanner`, `GoldProgressBar`, `MapMarker`, `LocationSheet`, `RupeeCounter`, `EmptyState`, `QuickAddSheet`, `PermissionExplainer`.

## Navigation
Bottom tabs: Home, Journal, World (center), Treasury, Hero. Global floating + shortcut. Preserve map camera state on back navigation.

## World hierarchy
World Atlas (illustrated region anchors) → Region Map (georeferenced vector data with fantasy style) → Location Sheet (quest board, history, memories). Region settings include polygon boundary, 15-mile nearby distance default and manual place overrides.

## Adding a place
Map + → Address / Drag Pin / Current Location → Name and icon → Confirm geographic pin → Choose region/nearby/atlas → Save. Long-press map to add. Don't change geo coordinates when moving labels or decorations.

## Quest quick-add
Global + → text title instantly → optional date/time, recurrence, location, difficulty, parent quest → Save. Keep initial capture possible with just title. Calendar and quests share schedule projections.

## Notifications
Pre-permission explanation → opt-in background location → enter region alert with actionable outstanding quests and cooldown. Respect quiet hours and ability to disable by region.

## Accessibility
VoiceOver labels for pins and controls; map locations available through searchable text list. Don't encode quest state in color alone. Fall back to non-animated rendering under reduced motion.
