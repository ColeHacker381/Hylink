# Acceptance Test Matrix

## Foundation
- [ ] App boots on iPhone development build; five tabs navigate; global quick add opens.
- [ ] Strict TS typecheck and lint succeed; an offline SQLite migration initializes schema.
- [ ] No real private addresses or financial data appear in demo seeds.

## Quests
- [ ] Add a task with only title in <=3 UI actions from Home.
- [ ] Due time and local timezone persist across restart and daylight-saving boundaries.
- [ ] Recurring quest has distinct occurrence keys; cannot collect XP twice for same occurrence.
- [ ] A completed quest persists offline and is reflected in journal and linked location.
- [ ] Outbox retries do not duplicate XP, rupees or achievements.

## Maps
- [ ] World atlas selects Danville (demo only) and restores atlas position when backing out.
- [ ] Regional map renders accurate coordinates with custom fantasy style and can zoom/pan.
- [ ] A place entered by address (mock adapter for tests) is geocoded, confirmed and stored.
- [ ] Dragged geographic pin updates lat/lng; moving a decorative label does not.
- [ ] Given a polygon, inside is in-region; outside within 15 miles is nearby; farther is atlas. Boundary and manual overrides covered.
- [ ] Adding a place does not recreate region raster artwork.

## Geofencing
- [ ] Only opted-in users register monitored regions; never exceed iOS 20-region ceiling.
- [ ] Repeated entry within cooldown emits at most one notification.
- [ ] No available actionable quest means no region-entry quest notification.
- [ ] Disabled permissions show a useful fallback and manual nearby quest screen.

## Treasury
- [ ] Amounts in integer cents; income, spending, transfer and budget totals calculated correctly.
- [ ] Virtual rupee redemptions do not change real financial balances.
- [ ] Goal achievement only once per threshold crossing; no rewards from unconfirmed projected earnings.

## UI/privacy
- [ ] Saved home addresses never appear in outbound logs or unauthorized AI context.
- [ ] Dynamic font size, screen reader labels and minimum tap targets verified.
- [ ] Export/import round-trip restores quests, places, progress and finance ledger without duplicate rewards.
