# Development Roadmap

## Milestone 0: Repository + docs
1. Bootstrap pnpm workspace, Expo Router app and packages; strict TS, lint, formatting, tests.
2. Add folder boundaries, interface contracts and navigation shell using sample data.
3. Add CI with typecheck, lint, unit tests and migration tests.

## Milestone 1: First functional app
4. SQLite migrations and typed repositories; event outbox plumbing.
5. Quest quick-add, list, edit, complete, due dates and recurrence.
6. Calendar daily/weekly screen, event creation and schedule projection.
7. Rule-based RPG ledger with configurable difficulty XP and idempotent processing.

## Milestone 2: Distinctive map prototype
8. MapLibre feasibility spike in custom Expo dev build; local fixture for Danville with mock non-private pins.
9. Implement parchment style with road/water layers and markers; validate accuracy and smooth zoom.
10. Atlas renderer with stable region anchors; region → location navigation.
11. Place editor (address provider adapter, drag pin, current location) and region polygon + nearby buffer.

## Milestone 3: Geolocation & polish
12. Opt-in geofencing with OS cap-aware selector and cool-down; physical device tests.
13. Location boards, quest filters, region/achievement progress and map cosmetics.

## Milestone 4: Finances & long-term features
14. Treasury income/expense/budget/goals, integer-cents arithmetic and export.
15. Rewards, achievement rules, hero profile, inventory and chronicles.
16. AI suggestions with consent, backups, integration adapters.

Every implementation ticket must name scope, interfaces, migration changes, test plan, and verification commands.
