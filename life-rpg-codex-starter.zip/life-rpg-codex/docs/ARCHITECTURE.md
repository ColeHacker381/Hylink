# Architecture v0.1

## Stack
- Expo/React Native/TypeScript, Expo Router.
- SQLite via expo-sqlite and a compatible Drizzle ORM version; migrations versioned and tested.
- Zustand only for transient UI state; domain data comes from repositories/use cases.
- MapLibre React Native for geospatial regional maps. Requires custom Expo development build, not Expo Go. Build a technical spike before adopting broadly.
- Custom static/interactive illustrated world atlas over separately stored geospatial anchors.
- Expo Location/TaskManager/Notifications for optional geofences, iOS 20 simultaneous regions maximum; prioritized monitored set and cooldowns.
- Tests: Vitest for pure TypeScript modules, React Native Testing Library for UI, on-device manual scenarios for GPS and map.

## Module boundaries
- quests: tasks, questlines, recurrence, lifecycle, location links.
- calendar: events, occurrence projection, scheduling, reminders.
- world: regions, saved places, boundaries, classification, region/place membership.
- map: atlas renderer, geospatial renderer, art pack, layers, editor; never owns coordinate source of truth.
- progression: XP ledger, levels, skills, rule sets.
- rewards: virtual rupee ledger and redeemable rewards; no real-money writes.
- treasury: monetary transactions, budgets, income, financial goal tracking.
- achievements: data-driven conditions, unlock records.
- hero: character appearance and profile.
- chronicle: milestone timeline and memories.
- notifications: geofence selection, delivery/suppression and preferences.
- ai: suggestion-only adapter, explicit confirmation for mutation.
- settings: feature flags, permission controls, export/import.

## Contract rules
1. Feature writes go through domain use-cases, not other features' tables.
2. Local cross-feature views use read-only projection/query services.
3. Persist a command's state change and event outbox row in one SQLite transaction.
4. Event handlers have unique `(consumer,event_id)` processing records and idempotent ledger keys.
5. Never use events to modify real-money transactions without a separately authorized Treasury command.
6. All events include event_id, type, schema_version, occurred_at, aggregate_id and payload.
7. Screen state holds navigation/selection; SQLite owns persistent truth.

## Design decisions
- Modular monolith, not microservices.
- Private local data primary. No cloud dependency required for MVP.
- Hybrid game rules: fixed audited ledger and lifecycle, configurable point curves, achievement data, quest templates, artifacts, rewards.
- World atlas illustrated position separate from real location; regional map uses georeferenced roads, water and saved pins with parchment vector styles.
- Render illustration layers from reusable assets; no AI-generated raster map as the geographic ground truth.
- Region eligibility based on manual promotion/relevance; one-off visits go into exploration atlas.
- A location outside an editable region polygon and within configurable buffer (default 15 miles, measured from polygon boundary) is 'nearby'; manual overrides allowed.
- Region completion tracks bounded achievements and discoveries, not the endlessly changing task backlog.

## Development caveats
- Validate MapLibre style, tile source licensing, address search licensing, offline policies, and compatibility before implementation expansion.
- Native geofence entry can be delayed or omitted by operating system; don't promise immediate alerts.
- Region polygons do not directly match OS circular geofences; use coarse monitored regions plus app-side polygon checks where location is available.
