# Codex Task 03 — Geographically accurate parchment map spike

Read AGENTS.md and docs/. Build a bounded technical proof of concept in a custom Expo development build using a compatible MapLibre React Native version. Use public licensed map data and fictional demo location pins in the general Danville region; do not store real private addresses. Style roads in antique ink, water in muted blue-green, terrain/parcels in beige and muted greens. Add camera zoom/pan, marker selection and a list alternative. Mark all assets with attribution and maintain geography accuracy.

Report whether layer styling, custom marker artwork, on-device performance, offline capability and map provider licensing are viable. Include real iPhone screenshots only if actually taken; otherwise state device tests pending. Do not attempt to generate a static AI base image as authoritative geography.
