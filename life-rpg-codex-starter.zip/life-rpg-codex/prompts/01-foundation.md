# Codex Task 01 — Bootstrap foundation

Read AGENTS.md and every file in docs/. Create an Expo + TypeScript + Expo Router project and pnpm monorepo fitting the architecture. Implement five accessible tab screens (Home, Journal, World, Treasury, Hero), mock data only, a global quick-add modal, design tokens and simple parchment-themed reusable components.

Constraints: no live GPS, no API keys, no real addresses, no bank integration; use compatible verified package versions and pin them in lockfile. Do not install MapLibre in this first task unless required for a spike. Keep screens thin. Add unit tests for navigation-independent domain helpers and component render states. Set up commands: typecheck, lint, test. Document any setup steps needed on Fedora vs Mac for native iPhone builds.

Acceptance: app starts, tabs work, quick add opens and closes, UI readable on small iPhone, test/typecheck/lint report results. Commit once validated; summarize files changed and any blockers.
