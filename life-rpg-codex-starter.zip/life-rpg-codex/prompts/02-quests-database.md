# Codex Task 02 — Persistent quest vertical slice

Read AGENTS.md and docs/. Implement SQLite migration infrastructure and repositories, Quest entity/use-case, task capture/edit/completion with due dates and location link nullable. Implement transactional durable domain event outbox, simple consumer dedup store, and versioned ruleset. Show persistent quests in Home and Journal. Do not implement real geofencing or treasury.

Tests: SQLite migration can initialize/reopen database; create-edit-complete persists; completing twice is idempotent; XP reward source key applies once despite event replay; due timestamp/timezone roundtrips; task list updates after restarting app. All writes go through use-cases. Summarize commands run and any constraints.
