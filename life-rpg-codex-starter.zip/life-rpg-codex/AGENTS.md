# Codex Agent Instructions

- Build an Expo + React Native + TypeScript app with Expo Router. Use a compatible current Expo SDK and lock resolved versions; do not assume SDK-specific APIs.
- Use TypeScript strict mode; avoid `any`, do not hardcode private addresses or actual financial balances.
- Offline-first, SQLite storage. Separate app features into `ui`, `domain`, `data`, `application`; never let screens write SQL directly.
- Feature domains own their writes; communicate via typed contracts/events. Use a durable event outbox and idempotent reward ledger for gameplay side effects.
- Monetary amounts are integer cents; currencies are separate from virtual rupees. Dates/times stored as UTC instants plus IANA timezone for local schedules; recurrence stores wall-time rules.
- All locations use WGS84 lat/lng. Rendered pixel coordinates are never authoritative geography. Atlas art placement and geographic positions are separate.
- Address lookup and any third-party mapping service must be adapter-based, mockable, and documented for licensing and privacy.
- Never request background location access until a user turns on the corresponding feature. Geofence testing on physical iOS devices with a custom development build.
- Users confirm new places/regions and AI-proposed changes. No automatic creation of permanent regions from a single visit.
- Build small vertical slices, add tests, run typecheck/lint/tests, and update decision notes with consequential changes. Never claim tests passed without running them.
- Match design guidance in `docs/UI_DESIGN.md` but prioritize legibility/accessibility over fantasy decoration.
