# Life RPG — Codex Starter Pack

Architecture version 0.1. Personal offline-first iPhone adventure organizer: medieval atlas, geographical region maps, quest/calendar system, treasury, RPG progression.

Read `AGENTS.md`, `docs/ARCHITECTURE.md`, and `docs/ROADMAP.md` before coding. Start with `prompts/01-foundation.md`. This pack is a specification, not an implemented app.
